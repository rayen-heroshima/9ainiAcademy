<?php

require_once 'C:\xampp\htdocs\PFA V0\PFA 2\Model\course.php';

?>