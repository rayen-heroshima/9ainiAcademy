

<section style="flex-direction: column; gap: 10%">

    <div class="container3">
        <form id="parentForm" action="submit.php" method="POST">
            <div class="container2">
            <input type="text" class="cours-title" name="title-chaptre" placeholder="cours-title..."  class="barcelona">
            <div class="lecture">
                <input type="text" name="title-video" placeholder="Lecture 1: Introduction....">
                <button type="button" id="openUploadModalBtn" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#uploadModal">
     +content
</button>
            </div>
            <button type="button" id="openCurriculumItemModalBtn" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#curriculumItemModal">
    +Curriculum
</button>
            </div>
       
            
            <button type="submit" class="btn btn-primary but" id="submitich" name="submit">Submit</button>
           
            </form>
        </div>
    <button class="btn btn-primary" id="addSectionButton">+ Section</button>
    
    
</section>
