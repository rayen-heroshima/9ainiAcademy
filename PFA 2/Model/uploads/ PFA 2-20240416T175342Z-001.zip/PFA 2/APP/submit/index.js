document.getElementById('courseStructure').addEventListener('click', function() {
    loadContent('content2.php');
});

document.getElementById('courseLandingPage').addEventListener('click', function() {
    loadContent('content.php');
});

function loadContent(url) {
    var arr=[];
    var data = {
        title: 'name',
        videoUrl: 'url',
        pdfUrl: 'url'
    };
    
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            
            document.getElementById("core").innerHTML = this.responseText;

            const inputElement = document.querySelector('.cours-title');
            inputElement.addEventListener('change', function() {
                data.title = inputElement.value;
                console.log(data); // Log updated data here
            });

            var uploadButton = document.getElementById('buttonUpload');
            uploadButton.addEventListener('click', (event) => {
                event.preventDefault();
                
                var uploadModal = document.getElementById('uploadModal');
                var modal = bootstrap.Modal.getInstance(uploadModal);
                modal.hide();
                const fileInput = document.getElementById('videoFile');
                const file = fileInput.files[0];
                
                if (file) {
                    console.log(file);
                    data.videoUrl = file.name;
                    console.log(data); // Log updated data here
                }
                var formData = new FormData(document.getElementById('childForm')); 
     fetch('http://localhost/PFA%20V0/PFA%202/Controller/controller.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(data => {
        // Handle the response data
        console.log(data);
    })
    .catch(error => {
        // Handle errors
        console.error('There was a problem with the fetch operation:', error);
    });
            });

            var uploadButton2 = document.getElementById('buttonUpload2');
            uploadButton2.addEventListener('click', (event) => {
                event.preventDefault();
                
                var uploadModal = document.getElementById('curriculumItemModal');
                var modal = bootstrap.Modal.getInstance(uploadModal);
                modal.hide();
                const fileInput = document.getElementById('curriculumItemFile');
                const file = fileInput.files[0];
                if (file) {
                    data.pdfUrl = file.name;
                    console.log(data); // Log updated data here
                }
                var formData = new FormData(document.getElementById('childform2')); 
                fetch('http://localhost/PFA%20V0/PFA%202/Controller/controller.php', {
                   method: 'POST',
                   body: formData
               })
               .then(response => {
                   if (!response.ok) {
                       throw new Error('Network response was not ok');
                   }
                   return response.text();
               })
               .then(data => {
                   // Handle the response data
                   console.log(data);
               })
               .catch(error => {
                   // Handle errors
                   console.error('There was a problem with the fetch operation:', error);
               });
            });

            document.getElementById('submitich').addEventListener('click', function(event) {
                
                
                fetch('http://localhost/PFA%20V0/PFA%202/Controller/controller.php', {
                    method: 'POST',
                    body: JSON.stringify(data)
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    console.log("the data is send it");
                    return response.text();
                })
                .then(data => {
                    // Handle the response data
                    console.log(data);
                })
                .catch(error => {
                    // Handle errors
                    console.error('There was a problem with the fetch operation:', error);
                });
            });

            document.getElementById("addSectionButton").addEventListener("click", function() {
                const originalContainer = document.querySelector('.container2');
                var clonedContainer = originalContainer.cloneNode(true);

                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'x';
                deleteButton.classList.add('btn', 'btn-danger');
                deleteButton.onclick = function() {
                    this.parentNode.remove();
                };
                clonedContainer.appendChild(deleteButton);

                const addButton = document.querySelector('.container2');
                addButton.after(clonedContainer);
            });
        }
    };
    xhttp.open("GET", url, true);
    xhttp.send();
}

window.onload = function() {
    loadContent('content2.php');
};
