<div class="img">
            <img src="../imgs/pretty-brunette-schoolgirl-standing-holding-yellow-backpack-folder-removebg.png" alt="" class="img-s">
            <p class="max">Discover new courses every day.</p>
            <p class="min">Explore courses from top educators worldwide.</p>


        </div>