<?php
$title = $subtitle = $description = $courseCategory = $filePath = $filePath2 =$titleChapter= "";
require_once 'C:\xampp\htdocs\PFA V0\PFA 2\Model\submit.php' ;
if (isset($_POST["title"])) {
    $title = $_POST["title"];
  }
  if (isset($_POST["subtitle"])) {
    $subtitle = trim($_POST["subtitle"]);
  } else {
    $subtitle = 'no';
  }
  if (isset($_POST["description"])) {
    $description = trim($_POST["description"]);
  }
  if (isset($_POST['course_category'])) {
    $courseCategory = htmlspecialchars($_POST['course_category']);
  }
  if (isset($_FILES['image'])) {
    $uploadDir = 'C:\xampp\htdocs\PFA V0\PFA 2\Model\uploads\ ';
    $uploadFile = $uploadDir . basename($_FILES['image']['name']);
    if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
      $filePath = $uploadFile;
      echo "File uploaded and saved to database.";
    } else {
     
      echo "Error uploading image. Please try again.";
    }
  } else {
   
   $filePath = ''; 
  }

 
  if (isset($_FILES["video-upload"])) {
    $uploadDir2 = 'C:\xampp\htdocs\PFA V0\PFA 2\Model\uploads\ ';
    $uploadFile2 = $uploadDir2 . basename($_FILES["video-upload"]["name"]);

    if (move_uploaded_file($_FILES["video-upload"]["tmp_name"], $uploadFile2)) {
      $filePath2 = $uploadFile2;
      echo "Video uploaded successfully.";
    } else {
    
      echo "Error uploading video. Please try again.";
      $filePath2="";
    }
  }


$course = new coursedatabase();

$course->connect();

$course->read($title, $subtitle, $description,$courseCategory, $filePath, $filePath2);




if (isset($_FILES['videoFile'])) {
  $uploadDir = 'C:\xampp\htdocs\PFA V0\PFA 2\Model\uploads\ ';
  $uploadFile = $uploadDir . basename($_FILES['videoFile']['name']);
  if (move_uploaded_file($_FILES['videoFile']['tmp_name'], $uploadFile)) {
    
    echo "File uploaded and saved to database.";
  } else {
   
    echo "Error uploading image. Please try again.";
  }
} 
if (isset($_FILES['uploadFile-quizz'])) {
  $uploadDir = 'C:\xampp\htdocs\PFA V0\PFA 2\Model\uploads\ ';
  $uploadFile = $uploadDir . basename($_FILES['uploadFile-quizz']['name']);
  if (move_uploaded_file($_FILES['uploadFile-quizz']['tmp_name'], $uploadFile)) {
    
    echo "File uploaded and saved to database.";
  } else {
   
    echo "Error uploading image. Please try again.";
  }
} 

$json_data = file_get_contents('php://input');
    
    // Decode the JSON data
    $data = json_decode($json_data, true); 
    print_r($data);
    $video = new videodatabase();
$video->connect();
print_r($data);


if(isset($data['title'])&&isset($data['videoUrl'])&&isset($data['pdfUrl'])){
  $titleChapter = isset($data['title']) ? $data['title'] : '';
   

  
  $uploadDir = 'C:\xampp\htdocs\PFA V0\PFA 2\Model\uploads\ ';
  $imagePath = $uploadDir . $filePath3;
  
  $pdfPath = $uploadDir . $filePath4;
  
  
    


$video->read($titleChapter,$imagePath, $pdfPath);




}








                         

?>