<?php
// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get the raw POST data
    
  
    echo "Data received successfully";
} else {
    // Handle other request methods (e.g., GET)
    echo "Invalid request method";
}
